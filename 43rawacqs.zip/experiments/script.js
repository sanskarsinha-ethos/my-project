document.addEventListener("DOMContentLoaded", function() {
    var readDocs = document.querySelector(".read-instructions");
    readDocs.style.display = "block";
});